INSERT INTO users (name,email,password)
VALUES ('Admin','admin@esmms.com','password123');