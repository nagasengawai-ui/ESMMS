<?php
namespace Core;

class Router {
    private $routes = [];

    public function add($route, $params = []) {
        $this->routes[$route] = $params;
    }

    public function dispatch($url) {
        $url = trim($url, '/');
        if (array_key_exists($url, $this->routes)) {
            $controller = "App\\Controllers\\" . $this->routes[$url]['controller'];
            $action = $this->routes[$url]['action'];
            $controllerObj = new $controller();
            $controllerObj->$action();
        } else {
            echo "404 Not Found";
        }
    }
}