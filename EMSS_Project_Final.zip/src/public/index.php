<?php
spl_autoload_register(function ($class) {
    $class = str_replace('\\', '/', $class);
    require __DIR__ . '/../' . $class . '.php';
});

$router = new Core\Router();
require __DIR__ . '/../routes/web.php';

$url = $_GET['url'] ?? '';
$router->dispatch($url);