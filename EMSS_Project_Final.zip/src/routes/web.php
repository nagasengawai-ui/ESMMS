<?php
$router->add('', ['controller' => 'AuthController', 'action' => 'login']);
$router->add('dashboard', ['controller' => 'AuthController', 'action' => 'dashboard']);
$router->add('employees', ['controller' => 'EmployeeController', 'action' => 'index']);