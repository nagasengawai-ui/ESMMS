<h2>Login Page</h2>
<a href="dashboard">Go to Dashboard</a>